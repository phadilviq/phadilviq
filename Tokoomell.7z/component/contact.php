<section class="features py-5">
    <div class="container">
      <div class="row">
        <div class="col-md-6 text-center">
          <div class="py-5">
          <ion-icon name="logo-whatsapp" class="h1"></ion-icon>
            <h4 class="element-title text-capitalize my-3">Chat via Whatsapp</h4>
            <p>08:00 - 23:00 / 7 days a week</p>
          </div>
        </div>
        <div class="col-md-6 text-center">
          <div class="py-5">
          <ion-icon name="mail-outline" class="h1"></ion-icon>
            <h4 class="element-title text-capitalize my-3">Send Email</h4>
            <p>Send your email to mlafa@gmail.com</p>
          </div>
        </div>
      </div>
    </div>
  </section>