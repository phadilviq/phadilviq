<section name="partnership" class="logo-bar py-5 my-5">
    <div class="container">
      <div class="row">
        <div class="logo-content d-flex flex-wrap justify-content-between">
          <img src="images/logo1.png" alt="logo" class="logo-image img-fluid">
          <img src="images/logo2.png" alt="logo" class="logo-image img-fluid">
          <img src="images/logo3.png" alt="logo" class="logo-image img-fluid">
          <img src="images/logo4.png" alt="logo" class="logo-image img-fluid">
          <img src="images/logo5.png" alt="logo" class="logo-image img-fluid">
        </div>
      </div>
    </div>
  </section>